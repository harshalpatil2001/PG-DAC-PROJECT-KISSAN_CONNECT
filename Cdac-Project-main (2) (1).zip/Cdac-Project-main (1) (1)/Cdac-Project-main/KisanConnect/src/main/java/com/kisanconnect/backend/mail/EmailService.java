package com.kisanconnect.backend.mail;
//kissanconnect
public class EmailService {

}
