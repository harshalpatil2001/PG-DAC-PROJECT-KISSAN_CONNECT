
function TermsandCondition()
{
    return(
        <center>
        <div className="col-3 card p-4 mt-4 mb-4 me-4 ms-4" style={{width: "50rem"}}>
        <div className="card-body">
        <h5 className="card-title">Terms & conditions</h5>
        <p className="card-text">If Buyer paid successfully to the farmer then Farmer has to deliver product in 15 days or return the payment to the buyer</p>
        
       </div>
       </div>
       </center>
    )
}

export default TermsandCondition;